import './App.css';
import { BrowserRouter, Route, Router, Routes } from 'react-router-dom';
import About from './component/page/about';
import Feature from './component/page/feature';
import Service from './component/page/service';
import Team from './component/page/team';
import Testimonial from './component/page/testimonial';
import Contact from './component/page/contact';
import Appointmen from './component/page/appointmen';
import A404 from './component/page/404';
import Home from './component/page/home';
import Page from './component/page/page';
import Master from './component/page/master';
import Project from './component/page/project';
import Login from './component/page/login';

function App() {
  return (
   <BrowserRouter>
   <Routes>
   <Route path="/" element={<Master/>}>
    <Route path="/about" element={<About/>}/>
    <Route path="/feature" element={<Feature/>}/>
    <Route path="/service" element={<Service/>}/>
    <Route path="/team" element={<Team/>}/>
    <Route path="/project" element={<Project/>}/>
    <Route path="/testimonial" element={<Testimonial/>}/>
    <Route path="/contact" element={<Contact/>}/>
    <Route path="/appointmen" element={<Appointmen/>}/>
    <Route path="/a404" element={<A404/>}/>
    <Route path="/" element={<Home/>}/>
    <Route path="/page" element={<Page/>}/>
    <Route path="/login" element={<Login/>}/>
    </Route>

   </Routes>
   </BrowserRouter>
  );
}

export default App;
