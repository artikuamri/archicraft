import { Link } from "react-router-dom";

export default function Header(){
    return(
        <>
        <div>
  <div
    className="container-fluid bg-dark p-0 wow fadeIn"
    data-wow-delay="0.1s"
  >
    <div className="row gx-0 d-none d-lg-flex">
      <div className="col-lg-7 px-5 text-start">
        <div className="h-100 d-inline-flex align-items-center py-3 me-3">
          <Link
            className="text-body px-2"
            to="tel:+0123456789"
          >
            <i className="fa fa-phone-alt text-primary me-2" />
            +918837568202
          </Link>
          <Link
            className="text-body px-2"
            to="mailto:info@example.com"
          >
            <i className="fa fa-envelope-open text-primary me-2" />
            artikumariihds@gmail.com
          </Link>
        </div>
      </div>
      <div className="col-lg-5 px-5 text-end">
        <div className="h-100 d-inline-flex align-items-center py-3 me-2">
          <Link
            className="text-body px-2"
            to=""
          >
            Terms
          </Link>
          <Link
            className="text-body px-2"
            to=""
          >
            Privacy
          </Link>
        </div>
        <div className="h-100 d-inline-flex align-items-center">
          <Link
            className="btn btn-sm-square btn-outline-body me-1"
            to=""
          >
            <i className="fab fa-facebook-f" />
          </Link>
          <Link
            className="btn btn-sm-square btn-outline-body me-1"
            to=""
          >
            <i className="fab fa-twitter" />
          </Link>
          <Link
            className="btn btn-sm-square btn-outline-body me-1"
            to=""
          >
            <i className="fab fa-linkedin-in" />
          </Link>
          <Link
            className="btn btn-sm-square btn-outline-body me-0"
            to=""
          >
            <i className="fab fa-instagram" />
          </Link>
        </div>
      </div>
    </div>
  </div>
</div><div>
  <nav
    className="navbar navbar-expand-lg bg-white navbar-light sticky-top py-lg-0 px-lg-5 wow fadeIn"
    data-wow-delay="0.1s"
  >
    <Link
      className="navbar-brand ms-4 ms-lg-0"
      to="index.html"
    >
      <h1 className="text-primary m-0">
        <img
          alt="Icon"
          className="me-3"
          src="/asset/img/icons/icon-1.png"
        />
        Arkitektur
      </h1>
    </Link>
    <button
      className="navbar-toggler me-4"
      data-bs-target="#navbarCollapse"
      data-bs-toggle="collapse"
      type="button"
    >
      <span className="navbar-toggler-icon" />
    </button>
    <div
      className="collapse navbar-collapse"
      id="navbarCollapse"
    >
      <div className="navbar-nav ms-auto p-4 p-lg-0">
        <Link
          className="nav-item nav-link active"
          to="/"
        >
          Home
        </Link>
        <Link
          className="nav-item nav-link "
          to="/about"
        >
          About
        </Link>
        <Link
          className="nav-item nav-link"
          to="/service"
        >
          Services
        </Link>
        <div className="nav-item dropdown">
          <Link
            className="nav-link dropdown-toggle"
            data-bs-toggle="dropdown"
            to="#"
          >
            Pages
          </Link>
          <div className="dropdown-menu border-0 m-0">
            <Link
              className="dropdown-item"
              to="/feature"
            >
              Our Features
            </Link>
            <Link
              className="dropdown-item"
              to="/project"
            >
              Our Projects
            </Link>
            <Link
              className="dropdown-item"
              to="/team"
            >
              Team Members
            </Link>
            <Link
              className="dropdown-item"
              to="/appointmen"
            >
              Appointment
            </Link>
            <Link
              className="dropdown-item"
              to="/testimonial"
            >
              Testimonial
            </Link>
            <Link
              className="dropdown-item"
              to="/a404"
            >
              404 Page
            </Link>
          </div>
        </div>
        <Link
          className="nav-item nav-link"
          to="/contact"
        >
          Contact
        </Link>
      </div>
      <Link
        className="btn btn-primary py-2 px-4 d-none d-lg-block"
        to=""
      >
        Appointment
      </Link>
    </div>
  </nav>
</div>
         </>
    )
}