export default function Footer(){
    return(
        <>
        <div>
  <div
    className="container-fluid bg-dark text-body footer mt-5 pt-5 px-0 wow fadeIn"
    data-wow-delay="0.1s"
  >
    <div className="container py-5">
      <div className="row g-5">
        <div className="col-lg-3 col-md-6">
          <h3 className="text-light mb-4">
            Address
          </h3>
          <p className="mb-2">
            <i className="fa fa-map-marker-alt text-primary me-3" />
            123 Street, punjab, phagwara
          </p>
          <p className="mb-2">
            <i className="fa fa-phone-alt text-primary me-3" />
            +918837568202
          </p>
          <p className="mb-2">
            <i className="fa fa-envelope text-primary me-3" />
            artikumariihds@gmail.com
          </p>
          <div className="d-flex pt-2">
            <a
              className="btn btn-square btn-outline-body me-1"
              href=""
            >
              <i className="fab fa-twitter" />
            </a>
            <a
              className="btn btn-square btn-outline-body me-1"
              href=""
            >
              <i className="fab fa-facebook-f" />
            </a>
            <a
              className="btn btn-square btn-outline-body me-1"
              href=""
            >
              <i className="fab fa-youtube" />
            </a>
            <a
              className="btn btn-square btn-outline-body me-0"
              href=""
            >
              <i className="fab fa-linkedin-in" />
            </a>
          </div>
        </div>
        <div className="col-lg-3 col-md-6">
          <h3 className="text-light mb-4">
            Services
          </h3>
          <a
            className="btn btn-link"
            href=""
          >
            Architecture
          </a>
          <a
            className="btn btn-link"
            href=""
          >
            3D Animation
          </a>
          <a
            className="btn btn-link"
            href=""
          >
            House Planning
          </a>
          <a
            className="btn btn-link"
            href=""
          >
            Interior Design
          </a>
          <a
            className="btn btn-link"
            href=""
          >
            Construction
          </a>
        </div>
        <div className="col-lg-3 col-md-6">
          <h3 className="text-light mb-4">
            Quick Links
          </h3>
          <a
            className="btn btn-link"
            href=""
          >
            About Us
          </a>
          <a
            className="btn btn-link"
            href=""
          >
            Contact Us
          </a>
          <a
            className="btn btn-link"
            href=""
          >
            Our Services
          </a>
          <a
            className="btn btn-link"
            href=""
          >
            Terms & Condition
          </a>
          <a
            className="btn btn-link"
            href=""
          >
            Support
          </a>
        </div>
        <div className="col-lg-3 col-md-6">
          <h3 className="text-light mb-4">
            Newsletter
          </h3>
          <p>
          A commitment to enduring design aesthetics reverberates through each piece of content they meticulously curate just for you
          </p>
          <div
            className="position-relative mx-auto"
            style={{
              maxWidth: '400px'
            }}
          >
            <input
              className="form-control bg-transparent w-100 py-3 ps-4 pe-5"
              placeholder="Your email"
              type="text"
            />
            <button
              className="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2"
              type="button"
            >
              SignUp
            </button>
          </div>
        </div>
      </div>
    </div>
    <div className="container-fluid copyright">
      <div className="container">
        <div className="row">
          <div className="col-md-6 text-center text-md-start mb-3 mb-md-0">
            {' '}
            <a href="#">
             
            </a>
           
          </div>
          <div className="col-md-6 text-center text-md-end">
            {' '}
            <a href="https://htmlcodex.com">
             
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <a
    className="btn btn-lg btn-primary btn-lg-square back-to-top"
    href="#"
  >
    <i className="bi bi-arrow-up" />
  </a>
</div>
        </>
    )
}