export default function Feature(){
    return(
        <>
        <div>
  <div className="container-xxl py-5">
    <div className="container">
      <div className="row g-5">
        <div
          className="col-lg-6 wow fadeInUp"
          data-wow-delay="0.1s"
        >
          <h4 className="section-title">
            Why Choose Us!
          </h4>
          <h1 className="display-5 mb-4">
            Why You Should Trust Us? Learn More About Us!
          </h1>
          <p className="mb-4">
          This architecture provides a basic structure for a feature management system, highlighting the key elements and interactions. It can be expanded and refined as needed to accommodate specific requirements and features, such as feature flagging or A/B testing.
          </p>
          <div className="row g-4">
            <div className="col-12">
              <div className="d-flex align-items-start">
                <img
                  alt="Icon"
                  className="flex-shrink-0"
                  src="/asset/img/icons/icon-2.png"
                />
                <div className="ms-4">
                  <h3>
                    Design Approach
                  </h3>
                  <p className="mb-0">
                  This architecture provides a basic structure for a design approach, highlighting the key elements and interactions. It can be expanded and refined as needed to accommodate specific design methodologies, tools, and deliverables.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-12">
              <div className="d-flex align-items-start">
                <img
                  alt="Icon"
                  className="flex-shrink-0"
                  src="/asset/img/icons/icon-3.png"
                />
                <div className="ms-4">
                  <h3>
                    Innovative Solutions
                  </h3>
                  <p className="mb-0">
                  This architecture provides a high-level overview of the innovative solutions architecture, showing the key actors, processes, applications, technology components, and relationships. It can be further refined and detailed as needed.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-12">
              <div className="d-flex align-items-start">
                <img
                  alt="Icon"
                  className="flex-shrink-0"
                  src="/asset/img/icons/icon-4.png"
                />
                <div className="ms-4">
                  <h3>
                    Project Management
                  </h3>
                  <p className="mb-0">
                  This architecture provides a high-level overview of the project management architecture, showing the key actors, processes, applications, technology components, and relationships. It can be further refined and detailed as needed
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          className="col-lg-6 wow fadeInUp"
          data-wow-delay="0.5s"
        >
          <div className="feature-img">
            <img
              alt=""
              className="img-fluid"
              src="/asset/img/about-2.jpg"
            />
            <img
              alt=""
              className="img-fluid"
              src="/asset/img/about-1.jpg"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

        </>
    )
}