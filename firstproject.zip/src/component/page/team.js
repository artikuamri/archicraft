export default function Team(){
    return(
        <>
        <div
    className="container-fluid page-header py-5 mb-5 wow fadeIn"
    data-wow-delay="0.1s"
  >
    <div className="container py-5">
      <h1 className="display-1 text-white animated slideInDown">
        Projects
      </h1>
      <nav aria-label="breadcrumb animated slideInDown">
        <ol className="breadcrumb text-uppercase mb-0">
          <li className="breadcrumb-item">
            <a
              className="text-white"
              href="#"
            >
              Home
            </a>
          </li>
          <li className="breadcrumb-item">
            <a
              className="text-white"
              href="#"
            >
              Pages
            </a>
          </li>
          <li
            aria-current="page"
            className="breadcrumb-item text-primary active"
          >
            team members
          </li>
        </ol>
      </nav>
    </div>
  </div>
        <div>
  <div className="container-xxl py-5">
    <div className="container">
      <div
        className="text-center mx-auto mb-5 wow fadeInUp"
        data-wow-delay="0.1s"
        style={{
          maxWidth: '600px'
        }}
      >
        <h4 className="section-title">
          Team Members
        </h4>
        <h1 className="display-5 mb-4">
          We Are Creative Architecture Team For Your Dream Home
        </h1>
      </div>
      <div className="row g-0 team-items">
        <div
          className="col-lg-3 col-md-6 wow fadeInUp"
          data-wow-delay="0.1s"
        >
          <div className="team-item position-relative">
            <div className="position-relative">
              <img
                alt=""
                className="img-fluid"
                src="/asset/img/team-1.jpg"
              />
              <div className="team-social text-center">
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
              </div>
            </div>
            <div className="bg-light text-center p-4">
              <h3 className="mt-2">
                Architect Name
                Arti 
              </h3>
              <span className="text-primary">
                Designation
              </span>
            </div>
          </div>
        </div>
        <div
          className="col-lg-3 col-md-6 wow fadeInUp"
          data-wow-delay="0.3s"
        >
          <div className="team-item position-relative">
            <div className="position-relative">
              <img
                alt=""
                className="img-fluid"
                src="/asset/img/team-2.jpg"
              />
              <div className="team-social text-center">
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
              </div>
            </div>
            <div className="bg-light text-center p-4">
              <h3 className="mt-2">
                Architect Name
                sumit
              </h3>
              <span className="text-primary">
                Designation
              </span>
            </div>
          </div>
        </div>
        <div
          className="col-lg-3 col-md-6 wow fadeInUp"
          data-wow-delay="0.5s"
        >
          <div className="team-item position-relative">
            <div className="position-relative">
              <img
                alt=""
                className="img-fluid"
                src="/asset/img/team-3.jpg"
              />
              <div className="team-social text-center">
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
              </div>
            </div>
            <div className="bg-light text-center p-4">
              <h3 className="mt-2">
                Architect Name
                chander bhan
              </h3>
              <span className="text-primary">
                Designation
              </span>
            </div>
          </div>
        </div>
        <div
          className="col-lg-3 col-md-6 wow fadeInUp"
          data-wow-delay="0.7s"
        >
          <div className="team-item position-relative">
            <div className="position-relative">
              <img
                alt=""
                className="img-fluid"
                src="/asset/img/team-4.jpg"
              />
              <div className="team-social text-center">
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
              </div>
            </div>
            <div className="bg-light text-center p-4">
              <h3 className="mt-2">
                Architect Name
                vivek
              </h3>
              <span className="text-primary">
                Designation
              </span>
            </div>
          </div>
        </div>
        <div
          className="col-lg-3 col-md-6 wow fadeInUp"
          data-wow-delay="0.1s"
        >
          <div className="team-item position-relative">
            <div className="position-relative">
              <img
                alt=""
                className="img-fluid"
                src="/asset/img/team-2.jpg"
              />
              <div className="team-social text-center">
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
              </div>
            </div>
            <div className="bg-light text-center p-4">
              <h3 className="mt-2">
                Architect Name
                sumit
              </h3>
              <span className="text-primary">
                Designation
              </span>
            </div>
          </div>
        </div>
        <div
          className="col-lg-3 col-md-6 wow fadeInUp"
          data-wow-delay="0.3s"
        >
          <div className="team-item position-relative">
            <div className="position-relative">
              <img
                alt=""
                className="img-fluid"
                src="/asset/img/team-3.jpg"
              />
              <div className="team-social text-center">
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
              </div>
            </div>
            <div className="bg-light text-center p-4">
              <h3 className="mt-2">
                Architect Name
                chander bhan
              </h3>
              <span className="text-primary">
                Designation
              </span>
            </div>
          </div>
        </div>
        <div
          className="col-lg-3 col-md-6 wow fadeInUp"
          data-wow-delay="0.5s"
        >
          <div className="team-item position-relative">
            <div className="position-relative">
              <img
                alt=""
                className="img-fluid"
                src="/asset/img/team-4.jpg"
              />
              <div className="team-social text-center">
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
              </div>
            </div>
            <div className="bg-light text-center p-4">
              <h3 className="mt-2">
                Architect Name
                vivek
              </h3>
              <span className="text-primary">
                Designation
              </span>
            </div>
          </div>
        </div>
        <div
          className="col-lg-3 col-md-6 wow fadeInUp"
          data-wow-delay="0.7s"
        >
          <div className="team-item position-relative">
            <div className="position-relative">
              <img
                alt=""
                className="img-fluid"
                src="/asset/img/team-1.jpg"
              />
              <div className="team-social text-center">
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-facebook-f" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-twitter" />
                </a>
                <a
                  className="btn btn-square"
                  href=""
                >
                  <i className="fab fa-instagram" />
                </a>
              </div>
            </div>
            <div className="bg-light text-center p-4">
              <h3 className="mt-2">
                Architect Name
                Arti
              </h3>
              <span className="text-primary">
                Designation
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
        </>
    )
}