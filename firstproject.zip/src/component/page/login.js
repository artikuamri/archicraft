/*export default function Login(){
    return(
        <>
        <div className="container">
        <h1 className="display-1 text-white animated slideInDown">
        Appointment
      </h1>
        <h1 className="text-center my-2">User Login</h1>
        <div className="row justify-content-center">
        <div className="col-md-2">
                    <label>Email</label>
                    <div className="col-md-7">
                    <input className="form-control"/>
                    <ul className="breadcrubs-custom-path pb-sm-5 pb-4 tect-center mb-md-5">
            <li>
                <Link to="/">home</Link>
            </li>
            <li className="active">/login</li>
            </ul>
                </div>
            </div>
            <div className="row  justify-content-center my-2">
                <div className="col-md-2">
                    <label>Password</label>
                </div>
                <div className="col-md-7">
                    <input type="password" class="form-control"/>
                </div>
            </div>
            <button className=" my-2 btn btn-primary d-block mx-auto">Submit</button>
        </div>
                </div>
        </>

    )
}*/