export default function About(){
    return(
        <>
        <div>
  <div className="container-xxl py-5">
    <div className="container">
      <div className="row g-5">
        <div
          className="col-lg-6 wow fadeIn"
          data-wow-delay="0.1s"
        >
          <div className="about-img">
            <img
              alt=""
              className="img-fluid"
              src="/asset/img/about-1.jpg"
            />
            <img
              alt=""
              className="img-fluid"
              src="/asset/img/about-2.jpg"
            />
          </div>
        </div>
        <div
          className="col-lg-6 wow fadeIn"
          data-wow-delay="0.5s"
        >
          <h4 className="section-title">
            About Us
          </h4>
          <h1 className="display-5 mb-4">
            A Creative Architecture Agency For Your Dream Home
          </h1>
          <p>
          This architecture provides a basic structure for an "About Us" page, highlighting the key elements and interactions. It can be expanded and refined as needed to accommodate specific requirements and features.
          </p>
          <p className="mb-4">
          </p>
          <div className="d-flex align-items-center mb-5">
            <div
              className="d-flex flex-shrink-0 align-items-center justify-content-center border border-5 border-primary"
              style={{
                height: '120px',
                width: '120px'
              }}
            >
              <h1
                className="display-1 mb-n2"
                data-toggle="counter-up"
              >
                25
              </h1>
            </div>
            <div className="ps-4">
              <h3>
                Years
              </h3>
              <h3>
                Working
              </h3>
              <h3 className="mb-0">
                Experience
              </h3>
            </div>
          </div>
          <a
            className="btn btn-primary py-3 px-5"
            href=""
          >
            Read More
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
        </>
    )
}