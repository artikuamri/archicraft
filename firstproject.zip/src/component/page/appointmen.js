export default function Appointmen(){
    return(
        <>
        <div>
  <div
    className="container-fluid page-header py-5 mb-5 wow fadeIn"
    data-wow-delay="0.1s"
  >
    <div className="container py-5">
      <h1 className="display-1 text-white animated slideInDown">
        Appointment
      </h1>
      <nav aria-label="breadcrumb animated slideInDown">
        <ol className="breadcrumb text-uppercase mb-0">
          <li className="breadcrumb-item">
            <a
              className="text-white"
              href="#"
            >
              Home
            </a>
          </li>
          <li className="breadcrumb-item">
            <a
              className="text-white"
              href="#"
            >
              Pages
            </a>
          </li>
          <li
            aria-current="page"
            className="breadcrumb-item text-primary active"
          >
            Appointment
          </li>
        </ol>
      </nav>
    </div>
  </div>
</div>
        <div>
  <div className="container-xxl py-5">
    <div className="container">
      <div className="row g-5">
        <div
          className="col-lg-6 wow fadeInUp"
          data-wow-delay="0.1s"
        >
          <h4 className="section-title">
            Appointment
          </h4>
          <h1 className="display-5 mb-4">
            Make An Appointment To Start Your Dream Project
          </h1>
          <p className="mb-4">
          This architecture provides a basic structure for an appointment system, highlighting the key elements and interactions. It can be expanded and refined as needed to accommodate specific requirements and features, such as payment processing or reminders.
          </p>
          <div className="row g-4">
            <div className="col-12">
              <div className="d-flex">
                <div
                  className="d-flex flex-shrink-0 align-items-center justify-content-center bg-light"
                  style={{
                    height: '65px',
                    width: '65px'
                  }}
                >
                  <i className="fa fa-2x fa-phone-alt text-primary" />
                </div>
                <div className="ms-4">
                  <p className="mb-2">
                    Call Us Now
                  </p>
                  <h3 className="mb-0">
                    +918837568202
                  </h3>
                </div>
              </div>
            </div>
            <div className="col-12">
              <div className="d-flex">
                <div
                  className="d-flex flex-shrink-0 align-items-center justify-content-center bg-light"
                  style={{
                    height: '65px',
                    width: '65px'
                  }}
                >
                  <i className="fa fa-2x fa-envelope-open text-primary" />
                </div>
                <div className="ms-4">
                  <p className="mb-2">
                    Mail Us Now
                  </p>
                  <h3 className="mb-0">
                    artikumari@gmail.com
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          className="col-lg-6 wow fadeInUp"
          data-wow-delay="0.5s"
        >
          <div className="row g-3">
            <div className="col-12 col-sm-6">
              <input
                className="form-control"
                placeholder="Your Name"
                style={{
                  height: '55px'
                }}
                type="text"
              />
            </div>
            <div className="col-12 col-sm-6">
              <input
                className="form-control"
                placeholder="Your Email"
                style={{
                  height: '55px'
                }}
                type="email"
              />
            </div>
            <div className="col-12 col-sm-6">
              <input
                className="form-control"
                placeholder="Your Mobile"
                style={{
                  height: '55px'
                }}
                type="text"
              />
            </div>
            <div className="col-12 col-sm-6">
              <select
                className="form-select"
                style={{
                  height: '55px'
                }}
              >
                <option selected>
                  Choose Service
                </option>
                <option value="1">
                  Service 1
                </option>
                <option value="2">
                  Service 2
                </option>
                <option value="3">
                  Service 3
                </option>
              </select>
            </div>
            <div className="col-12 col-sm-6">
              <div
                className="date"
                data-target-input="nearest"
                id="date"
              >
                <input
                  className="form-control datetimepicker-input"
                  data-target="#date"
                  data-toggle="datetimepicker"
                  placeholder="Choose Date"
                  style={{
                    height: '55px'
                  }}
                  type="text"
                />
              </div>
            </div>
            <div className="col-12 col-sm-6">
              <div
                className="time"
                data-target-input="nearest"
                id="time"
              >
                <input
                  className="form-control datetimepicker-input"
                  data-target="#time"
                  data-toggle="datetimepicker"
                  placeholder="Choose Date"
                  style={{
                    height: '55px'
                  }}
                  type="text"
                />
              </div>
            </div>
            <div className="col-12">
              <textarea
                className="form-control"
                placeholder="Message"
                rows="5"
              />
            </div>
            <div className="col-12">
              <button
                className="btn btn-primary w-100 py-3"
                type="submit"
              >
                Book Appointment
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

        </>
    )
}