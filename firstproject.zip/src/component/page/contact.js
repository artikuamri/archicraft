export default function Contact(){
    return(
        <>
        <div><div className="container-xxl py-5">
  
    <div className="container">
      <div
        className="text-center mx-auto mb-5 wow fadeInUp"
        data-wow-delay="0.1s"
        style={{
          maxWidth: '600px'
        }}
      >
        <h4 className="section-title">
          Contact Us
        </h4>
        <h1 className="display-5 mb-4">
          If You Have Any Query, Please Feel Free Contact Us
        </h1>
      </div>
      <div className="row g-5">
        <div
          className="col-lg-6 wow fadeInUp"
          data-wow-delay="0.1s"
        >
          <div className="d-flex flex-column justify-content-between h-100">
            <div className="bg-light d-flex align-items-center w-100 p-4 mb-4">
              <div
                className="d-flex flex-shrink-0 align-items-center justify-content-center bg-dark"
                style={{
                  height: '55px',
                  width: '55px'
                }}
              >
                <i className="fa fa-map-marker-alt text-primary" />
              </div>
              <div className="ms-4">
                <p className="mb-2">
                  Address
                </p>
                <h3 className="mb-0">
                  123 Street, punjab, phagwara
                </h3>
              </div>
            </div>
            <div className="bg-light d-flex align-items-center w-100 p-4 mb-4">
              <div
                className="d-flex flex-shrink-0 align-items-center justify-content-center bg-dark"
                style={{
                  height: '55px',
                  width: '55px'
                }}
              >
                <i className="fa fa-phone-alt text-primary" />
              </div>
              <div className="ms-4">
                <p className="mb-2">
                  Call Us Now
                </p>
                <h3 className="mb-0">
                  +918837568202
                </h3>
              </div>
            </div>
            <div className="bg-light d-flex align-items-center w-100 p-4">
              <div
                className="d-flex flex-shrink-0 align-items-center justify-content-center bg-dark"
                style={{
                  height: '55px',
                  width: '55px'
                }}
              >
                <i className="fa fa-envelope-open text-primary" />
              </div>
              <div className="ms-4">
                <p className="mb-2">
                  Mail Us Now
                </p>
                <h3 className="mb-0">
                  artikumariihds@gmail.com
                </h3>
              </div>
            </div>
          </div>
        </div>
        <div
          className="col-lg-6 wow fadeInUp"
          data-wow-delay="0.5s"
        >
          <p className="mb-4">
            The contact form is currently inactive. Get a functional and working contact form with Ajax & PHP in a few minutes. Just copy and paste the files, add a little code and you're done.{' '}
            <a href="https://htmlcodex.com/contact-form">
              Download Now
            </a>
            .
          </p>
          <form>
            <div className="row g-3">
              <div className="col-md-6">
                <div className="form-floating">
                  <input
                    className="form-control"
                    id="name"
                    placeholder="Your Name"
                    type="text"
                  />
                  <label htmlFor="name">
                    Your Name
                  </label>
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-floating">
                  <input
                    className="form-control"
                    id="email"
                    placeholder="Your Email"
                    type="email"
                  />
                  <label htmlFor="email">
                    Your Email
                  </label>
                </div>
              </div>
              <div className="col-12">
                <div className="form-floating">
                  <input
                    className="form-control"
                    id="subject"
                    placeholder="Subject"
                    type="text"
                  />
                  <label htmlFor="subject">
                    Subject
                  </label>
                </div>
              </div>
              <div className="col-12">
                <div className="form-floating">
                  <textarea
                    className="form-control"
                    id="message"
                    placeholder="Leave a message here"
                    style={{
                      height: '100px'
                    }}
                  />
                  <label htmlFor="message">
                    Message
                  </label>
                </div>
              </div>
              <div className="col-12">
                <button
                  className="btn btn-primary w-100 py-3"
                  type="submit"
                >
                  Send Message
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div
    className="container-xxl pt-5 px-0 wow fadeIn"
    data-wow-delay="0.1s"
  >
    <iframe
      allowFullScreen
      aria-hidden="false"
      className="w-100 mb-n2"
      frameBorder="0"
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3001156.4288297426!2d-78.01371936852176!3d42.72876761954724!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4ccc4bf0f123a5a9%3A0xddcfc6c1de189567!2sNew%20York%2C%20USA!5e0!3m2!1sen!2sbd!4v1603794290143!5m2!1sen!2sbd"
      style={{
        height: '450px'
      }}
      tabIndex="0"
    />
  </div>
</div>
        </>
    )
}